using APITestAutomation.Helper;
using APITestAutomation.Models;
using APITestAutomation.Models.Request;
using NUnit.Framework;
using RestSharp;


namespace APITestAutomation.StepDefinitions
{
    [Binding]
    public class UsersStepDefinitions
    {

        private string BASE_URL = Hooks1.configSetting.BaseURL;
        private readonly CreateUserReq createUserReq;
        private RestResponse response;

        public UsersStepDefinitions(CreateUserReq createUserReq)
        {
            this.createUserReq = createUserReq;
        }

        [Given(@"I input name ""([^""]*)""")]
        public void GivenIInputName(string name)
        {
            createUserReq.name = name;
        }

        [Given(@"I input role ""([^""]*)""")]
        public void GivenIInputRole(string role)
        {
            createUserReq.job = role;
        }

        [When(@"I send create user request")]
        public async System.Threading.Tasks.Task WhenISendCreateUserRequestAsync()
        {
            var api = new ApplicationHelper();
            response = await api.CreateNewUser(BASE_URL, createUserReq);
        }

        [Then(@"validate user is created")]
        public void ThenValidateUserIsCreated()
        {
            var content = HandleContent.GetContent<CreateUserRes>(response);
            Assert.AreEqual(createUserReq.name, content.name);
            Assert.AreEqual(createUserReq.job, content.job);
        }

        [When(@"I send update role user request")]
        public async System.Threading.Tasks.Task WhenISendUpdateRoleUserRequest()
        {
            var api = new ApplicationHelper();
            response = await api.UpdateUserWithPatch(BASE_URL, createUserReq);
        }

        [Then(@"validate user is updated with status code (.*)")]
        public void ThenValidateUserIsUpdatedWithStatusCode(int statusCode)
        {
            Assert.AreEqual(statusCode, Convert.ToInt32(response.StatusCode), "Status Code not matched");
        }   
       

        [When(@"I send update user request with input request")]
        public async System.Threading.Tasks.Task WhenISendUpdateUserRequestWithInputRequest()
        {
            var api = new ApplicationHelper();
            response = await api.UpdateUserWithPut(BASE_URL, createUserReq);
        }

        [When(@"I send Get list user request")]
        public void WhenISendGetListUserRequest()
        {
            var api = new ApplicationHelper();
            response = api.GetUsers(BASE_URL);

        }


        [Then(@"validate user ""([^""]*)"" exists in the list")]
        public void ThenValidateUserExistsInTheList(string user)
        {
            Assert.IsTrue(response.Content.Contains(user), "User not found in the list");
        }

        [When(@"I send Get user request with user id (.*)")]
        public void WhenISendGetUserRequestWithUserId(int userId)
        {
            var api = new ApplicationHelper();
            response = api.GetSingleUsers(BASE_URL, userId.ToString());
        }

        [Then(@"validate api response")]
        public void ThenValidateApiResponse()
        {
            Assert.AreEqual(200, Convert.ToInt32(response.StatusCode)," API response is not 200 . Check the logs");
        }
    }
}
