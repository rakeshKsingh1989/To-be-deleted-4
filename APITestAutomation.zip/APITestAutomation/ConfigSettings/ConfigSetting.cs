﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APITestAutomation.ConfigSettings
{
    public class ConfigSetting
    {
        public string BaseURL{get;set;}
    }
}
