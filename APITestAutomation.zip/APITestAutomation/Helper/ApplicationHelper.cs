﻿using RestSharp;
using APITestAutomation.Models.Request;

namespace APITestAutomation.Helper
{
    public class ApplicationHelper
    {
        private APIHelper helper;

        public ApplicationHelper()
        {
            helper = new APIHelper();
        }
        public RestResponse GetUsers(string baseUrl)
        {
            
            var client = helper.SetUrl(baseUrl, "api/users?page=2");
            var request = helper.CreateGetRequest();
            request.RequestFormat = DataFormat.Json;
            var response = helper.GetResponse(client, request);
            return response;
        }

        public RestResponse GetSingleUsers(string baseUrl, string userId)
        {
           
            var client = helper.SetUrl(baseUrl, "api/users/"+ userId);
            var request = helper.CreateGetRequest();
            request.RequestFormat = DataFormat.Json;
            var response = helper.GetResponse(client, request);
            return response;
        }

        public async Task<RestResponse> CreateNewUser(string baseUrl, dynamic payload)
        {
            var client = helper.SetUrl(baseUrl, "api/users");
            //var jsonString = HandleContent.SerializeJsonString(payload);
            var request = helper.CreatePostRequest<CreateUserReq>(payload);
            var response = await helper.GetResponseAsync(client, request);
            return response;
        }


        public async Task<RestResponse> UpdateUserWithPut(string baseUrl, dynamic payload)
        {
            var client = helper.SetUrl(baseUrl, "api/users/2");
            //var jsonString = HandleContent.SerializeJsonString(payload);
            var request = helper.CreatePutRequest<CreateUserReq>(payload);
            var response = await helper.GetResponseAsync(client, request);
            return response;
        }


        public async Task<RestResponse> UpdateUserWithPatch(string baseUrl, dynamic payload)
        {
            var client = helper.SetUrl(baseUrl, "api/users/2");
            //var jsonString = HandleContent.SerializeJsonString(payload);
            var request = helper.CreatePatchRequest<CreateUserReq>(payload);
            var response = await helper.GetResponseAsync(client, request);
            return response;
        }
    }
}
